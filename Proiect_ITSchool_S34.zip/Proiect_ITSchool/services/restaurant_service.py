class RestaurantService:
    def __init__(self, restaurants):
        self.restaurants = restaurants

    def get_all(
        self,
        city=None,
        is_open=None,
        min_rating=None,
        name=None
    ):
        filtered_restaurants = []

        for restaurant in self.restaurants:
            if city is not None:
                if restaurant["city"].lower() != city.lower():
                    continue

            if is_open is not None:
                if restaurant["is_open"] != is_open:
                    continue

            if min_rating is not None:
                if restaurant["rating"] < min_rating:
                    continue

            if name is not None:
                if name.lower() not in restaurant["name"].lower():
                    continue

            filtered_restaurants.append(restaurant)

        return filtered_restaurants

    def find_by_id(self, restaurant_id):
        for restaurant in self.restaurants:
            if restaurant["id"] == restaurant_id:
                return restaurant

        return None

    def get_next_id(self):
        max_id = 0

        for restaurant in self.restaurants:
            if restaurant["id"] > max_id:
                max_id = restaurant["id"]

        return max_id + 1

    def restaurant_exists(
        self,
        restaurant_name,
        city,
        excluded_id=None
    ):
        for restaurant in self.restaurants:
            same_name = (
                restaurant["name"].lower()
                == restaurant_name.lower()
            )

            same_city = (
                restaurant["city"].lower()
                == city.lower()
            )

            if same_name and same_city:
                if excluded_id is None:
                    return True

                if restaurant["id"] != excluded_id:
                    return True

        return False

    def create(self, restaurant_data):
        new_restaurant = {
            "id": self.get_next_id(),
            "name": restaurant_data.name,
            "city": restaurant_data.city,
            "address": restaurant_data.address,
            "rating": restaurant_data.rating,
            "is_open": restaurant_data.is_open
        }

        self.restaurants.append(new_restaurant)

        return new_restaurant

    def update(self, restaurant, restaurant_data):
        restaurant["name"] = restaurant_data.name
        restaurant["city"] = restaurant_data.city
        restaurant["address"] = restaurant_data.address
        restaurant["rating"] = restaurant_data.rating
        restaurant["is_open"] = restaurant_data.is_open

        return restaurant

    def patch(self, restaurant, updates):
        for key in updates:
            restaurant[key] = updates[key]

        return restaurant

    def delete(self, restaurant):
        self.restaurants.remove(restaurant)

        return restaurant