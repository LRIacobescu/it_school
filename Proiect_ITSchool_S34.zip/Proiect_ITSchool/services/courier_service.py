class CourierService:
    def __init__(self, couriers):
        self.couriers = couriers

    def get_all(
        self,
        active=None,
        first_name=None,
        last_name=None
    ):
        filtered_couriers = []

        for courier in self.couriers:
            if active is not None:
                if courier["active"] != active:
                    continue

            if first_name is not None:
                if (
                    first_name.lower()
                    not in courier["first_name"].lower()
                ):
                    continue

            if last_name is not None:
                if (
                    last_name.lower()
                    not in courier["last_name"].lower()
                ):
                    continue

            filtered_couriers.append(courier)

        return filtered_couriers

    def find_by_id(self, courier_id):
        for courier in self.couriers:
            if courier["id"] == courier_id:
                return courier

        return None

    def get_next_id(self):
        max_id = 0

        for courier in self.couriers:
            if courier["id"] > max_id:
                max_id = courier["id"]

        return max_id + 1

    def phone_exists(self, phone, excluded_id=None):
        for courier in self.couriers:
            same_phone = courier["phone"] == phone

            if same_phone:
                if excluded_id is None:
                    return True

                if courier["id"] != excluded_id:
                    return True

        return False

    def create(self, courier_data):
        new_courier = {
            "id": self.get_next_id(),
            "first_name": courier_data.first_name,
            "last_name": courier_data.last_name,
            "phone": courier_data.phone,
            "active": courier_data.active
        }

        self.couriers.append(new_courier)

        return new_courier

    def update(self, courier, courier_data):
        courier["first_name"] = courier_data.first_name
        courier["last_name"] = courier_data.last_name
        courier["phone"] = courier_data.phone
        courier["active"] = courier_data.active

        return courier

    def patch(self, courier, updates):
        for key in updates:
            courier[key] = updates[key]

        return courier

    def delete(self, courier):
        self.couriers.remove(courier)

        return courier