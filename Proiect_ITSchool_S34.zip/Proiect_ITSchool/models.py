from sqlalchemy import Boolean
from sqlalchemy import Column
from sqlalchemy import Float
from sqlalchemy import Integer
from sqlalchemy import String

from database import Base

class Category(Base):
    __tablename__ = "categories"

    id = Column(
        Integer,
        primary_key = True,
        index = True
    )

    name = Column(
        String(100),
        unique = True,
        nullable = False
    )

class Product(Base):
    __tablename__ = "products"

    id = Column(
        Integer,
        primary_key = True,
        index = True
    )

    name = Column(
        String(100),
        unique = True,
        nullable = False
    )

    description = Column(
        String(500),
        default = ""
    )

    price = Column(
        Float,
        nullable = False
    )

    category = Column(
        String(100),
        nullable = False
    )

    available = Column(
        Boolean,
        default = True,
        nullable = False
    )