from typing import Optional

from fastapi import APIRouter
from fastapi import HTTPException
from fastapi import status

from data import couriers
from schemas import CourierCreate
from schemas import CourierPatch
from schemas import CourierUpdate
from services.courier_service import CourierService


router = APIRouter(
    prefix="/couriers",
    tags=["Couriers"]
)


courier_service = CourierService(couriers)


@router.get("")
def get_couriers(
    active: Optional[bool] = None,
    first_name: Optional[str] = None,
    last_name: Optional[str] = None
):
    return courier_service.get_all(
        active,
        first_name,
        last_name
    )


@router.get("/{courier_id}")
def get_courier_by_id(courier_id: int):
    courier = courier_service.find_by_id(courier_id)

    if courier is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Curierul nu a fost gasit"
        )

    return courier


@router.post(
    "",
    status_code=status.HTTP_201_CREATED
)
def create_courier(courier: CourierCreate):
    if courier_service.phone_exists(courier.phone):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "Exista deja un curier "
                "cu acest numar de telefon"
            )
        )

    return courier_service.create(courier)


@router.put("/{courier_id}")
def update_courier(
    courier_id: int,
    updated_courier: CourierUpdate
):
    courier = courier_service.find_by_id(courier_id)

    if courier is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Curierul nu a fost gasit"
        )

    if courier_service.phone_exists(
        updated_courier.phone,
        courier_id
    ):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "Exista deja un curier "
                "cu acest numar de telefon"
            )
        )

    return courier_service.update(
        courier,
        updated_courier
    )


@router.patch("/{courier_id}")
def patch_courier(
    courier_id: int,
    courier_update: CourierPatch
):
    courier = courier_service.find_by_id(courier_id)

    if courier is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Curierul nu a fost gasit"
        )

    updates = courier_update.model_dump(
        exclude_unset=True
    )

    if len(updates) == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Trebuie trimis cel putin un camp"
        )

    if "phone" in updates:
        if courier_service.phone_exists(
            updates["phone"],
            courier_id
        ):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                    "Exista deja un curier "
                    "cu acest numar de telefon"
                )
            )

    return courier_service.patch(
        courier,
        updates
    )


@router.delete("/{courier_id}")
def delete_courier(courier_id: int):
    courier = courier_service.find_by_id(courier_id)

    if courier is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Curierul nu a fost gasit"
        )

    if courier["active"] is True:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Un curier activ nu poate fi sters"
        )

    deleted_courier = courier_service.delete(courier)

    return {
        "message": "Curierul a fost sters",
        "deleted_courier": deleted_courier
    }