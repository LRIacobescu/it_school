from typing import Optional

from pydantic import BaseModel
from pydantic import Field
from pydantic import ConfigDict

class ProductCreate(BaseModel):
    name: str = Field(min_length=2)
    description: str = ""
    price: float = Field(gt=0)
    category: str = Field(min_length=2)
    available: bool = True


class ProductUpdate(BaseModel):
    name: str = Field(min_length=2)
    description: str
    price: float = Field(gt=0)
    category: str = Field(min_length=2)
    available: bool


class ProductPatch(BaseModel):
    name: Optional[str] = Field(
        default=None,
        min_length=2
    )

    description: Optional[str] = None

    price: Optional[float] = Field(
        default=None,
        gt=0
    )

    category: Optional[str] = Field(
        default=None,
        min_length=2
    )

    available: Optional[bool] = None

class ProductResponse(BaseModel):
    model_config = ConfigDict(from_attributes = True)
    id: int
    name: str
    description: str
    price: float
    category: str
    available: bool

    # product.id
    # product.name
    # product.price


class CategoryCreate(BaseModel):
    name: str = Field(min_length=2)


class CategoryUpdate(BaseModel):
    name: str = Field(min_length=2)


class CategoryPatch(BaseModel):
    name: Optional[str] = Field(
        default=None,
        min_length=2
    )

class CategoryResponse(BaseModel):
    model_config = ConfigDict(from_attributes = True)
    id: int
    name: str

class RestaurantCreate(BaseModel):
    name: str = Field(min_length=2)
    city: str = Field(min_length=2)
    address: str = Field(min_length=5)
    rating: float = Field(ge=0, le=5)
    is_open: bool = True


class RestaurantUpdate(BaseModel):
    name: str = Field(min_length=2)
    city: str = Field(min_length=2)
    address: str = Field(min_length=5)
    rating: float = Field(ge=0, le=5)
    is_open: bool


class RestaurantPatch(BaseModel):
    name: Optional[str] = Field(
        default=None,
        min_length=2
    )

    city: Optional[str] = Field(
        default=None,
        min_length=2
    )

    address: Optional[str] = Field(
        default=None,
        min_length=5
    )

    rating: Optional[float] = Field(
        default=None,
        ge=0,
        le=5
    )

    is_open: Optional[bool] = None


class OrderCreate(BaseModel):
    customer_name: str = Field(min_length=2)
    total_price: float = Field(gt=0)
    number_of_products: int = Field(gt=0)
    delivery_fee: float = Field(default=10, ge=0)
    status: str = "new"


class OrderUpdate(BaseModel):
    customer_name: str = Field(min_length=2)
    total_price: float = Field(gt=0)
    number_of_products: int = Field(gt=0)
    delivery_fee: float = Field(ge=0)
    status: str = Field(min_length=2)


class OrderPatch(BaseModel):
    customer_name: Optional[str] = Field(
        default=None,
        min_length=2
    )

    total_price: Optional[float] = Field(
        default=None,
        gt=0
    )

    number_of_products: Optional[int] = Field(
        default=None,
        gt=0
    )

    delivery_fee: Optional[float] = Field(
        default=None,
        ge=0
    )

    status: Optional[str] = Field(
        default=None,
        min_length=2
    )


class CourierCreate(BaseModel):
    first_name: str = Field(min_length=2)
    last_name: str = Field(min_length=2)

    phone: str = Field(
        min_length=10,
        max_length=15
    )

    active: bool = True


class CourierUpdate(BaseModel):
    first_name: str = Field(min_length=2)
    last_name: str = Field(min_length=2)

    phone: str = Field(
        min_length=10,
        max_length=15
    )

    active: bool


class CourierPatch(BaseModel):
    first_name: Optional[str] = Field(
        default=None,
        min_length=2
    )

    last_name: Optional[str] = Field(
        default=None,
        min_length=2
    )

    phone: Optional[str] = Field(
        default=None,
        min_length=10,
        max_length=15
    )

    active: Optional[bool] = None