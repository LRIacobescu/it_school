from fastapi import FastAPI

import models
from database import Base, engine
from routers import categories
from routers import couriers
from routers import orders
from routers import products
from routers import restaurants

Base.metadata.create_all(bind = engine)

app = FastAPI(
    title="Food Delivery API",
    version="2.0.0"
)


app.include_router(products.router)
app.include_router(categories.router)
app.include_router(restaurants.router)
app.include_router(orders.router)
app.include_router(couriers.router)


@app.get("/", tags=["General"])
def home():
    return {
        "message": "Food Delivery APP!"
    }


@app.get("/status", tags=["General"])
def get_status():
    return {
        "app": "Food Delivery API",
        "status": "running",
        "version": "2.0.0"
    }