restaurants = [
    {
        "id": 1,
        "name": "Pizza House",
        "city": "Timisoara",
        "address": "Strada Unirii 10",
        "rating": 4.7,
        "is_open": True
    },
    {
        "id": 2,
        "name": "Burger Point",
        "city": "Timisoara",
        "address": "Strada Victoriei 15",
        "rating": 4.5,
        "is_open": False
    },
    {
        "id": 3,
        "name": "Pasta Corner",
        "city": "Arad",
        "address": "Bulevardul Central 8",
        "rating": 4.8,
        "is_open": True
    }
]


orders = [
    {
        "id": 1,
        "customer_name": "Andrei Popescu",
        "total_price": 87,
        "number_of_products": 2,
        "delivery_fee": 10,
        "status": "new"
    },
    {
        "id": 2,
        "customer_name": "Maria Ionescu",
        "total_price": 120,
        "number_of_products": 3,
        "delivery_fee": 0,
        "status": "delivered"
    },
    {
        "id": 3,
        "customer_name": "Ioana Stan",
        "total_price": 64,
        "number_of_products": 2,
        "delivery_fee": 10,
        "status": "preparing"
    },
    {
        "id": 4,
        "customer_name": "George Marin",
        "total_price": 45,
        "number_of_products": 1,
        "delivery_fee": 10,
        "status": "cancelled"
    }
]


couriers = [
    {
        "id": 1,
        "first_name": "Mihai",
        "last_name": "Popescu",
        "phone": "0712345678",
        "active": True
    },
    {
        "id": 2,
        "first_name": "Andrei",
        "last_name": "Ionescu",
        "phone": "0723456789",
        "active": False
    },
    {
        "id": 3,
        "first_name": "Alex",
        "last_name": "Dumitrescu",
        "phone": "0734567890",
        "active": True
    }
]