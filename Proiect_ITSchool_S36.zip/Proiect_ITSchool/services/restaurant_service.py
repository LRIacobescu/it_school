from sqlalchemy import func
from sqlalchemy import select

from models import Restaurant


class RestaurantService:
    def __init__(self, db):
        # Salvam sesiunea SQLAlchemy in obiectul curent.
        self.db = db

    def get_all(
        self,
        city=None,
        is_open=None,
        min_rating=None,
        name=None
    ):
        # Construim SELECT * FROM restaurants.
        statement = select(Restaurant)

        # Filtram dupa oras.
        #
        # func.lower transforma valoarea coloanei
        # in litere mici la nivel SQL.
        if city is not None:
            statement = statement.where(
                func.lower(Restaurant.city)
                == city.lower()
            )

        # Filtram restaurantele deschise sau inchise.
        if is_open is not None:
            statement = statement.where(
                Restaurant.is_open == is_open
            )

        # Filtram restaurantele care au rating-ul
        # mai mare sau egal cu valoarea trimisa.
        if min_rating is not None:
            statement = statement.where(
                Restaurant.rating >= min_rating
            )

        # ilike cauta textul fara diferenta intre
        # litere mari si litere mici.
        if name is not None:
            statement = statement.where(
                Restaurant.name.ilike(
                    "%" + name + "%"
                )
            )

        # Ordonam rezultatele dupa ID.
        statement = statement.order_by(
            Restaurant.id
        )

        # Executam SELECT-ul si returnam toate
        # obiectele Restaurant gasite.
        restaurants = self.db.scalars(
            statement
        ).all()

        return restaurants

    def find_by_id(self, restaurant_id):
        # db.get cauta obiectul dupa cheia primara.
        restaurant = self.db.get(
            Restaurant,
            restaurant_id
        )

        return restaurant

    def restaurant_exists(
        self,
        restaurant_name,
        city,
        excluded_id=None
    ):
        # Consideram un restaurant duplicat daca are:
        # - acelasi nume;
        # - acelasi oras.
        statement = select(Restaurant).where(
            func.lower(Restaurant.name)
            == restaurant_name.lower(),
            func.lower(Restaurant.city)
            == city.lower()
        )

        # La PUT si PATCH excludem restaurantul
        # pe care il actualizam.
        if excluded_id is not None:
            statement = statement.where(
                Restaurant.id != excluded_id
            )

        restaurant = self.db.scalar(statement)

        return restaurant is not None

    def create(self, restaurant_data):
        # Construim un obiect ORM Restaurant.
        new_restaurant = Restaurant(
            name=restaurant_data.name,
            city=restaurant_data.city,
            address=restaurant_data.address,
            rating=restaurant_data.rating,
            is_open=restaurant_data.is_open
        )

        # Pregatim obiectul pentru INSERT.
        self.db.add(new_restaurant)

        # Confirmam tranzactia.
        self.db.commit()

        # Recitim obiectul pentru a primi ID-ul generat.
        self.db.refresh(new_restaurant)

        return new_restaurant

    def update(self, restaurant, restaurant_data):
        # PUT actualizeaza toate campurile.
        restaurant.name = restaurant_data.name
        restaurant.city = restaurant_data.city
        restaurant.address = restaurant_data.address
        restaurant.rating = restaurant_data.rating
        restaurant.is_open = restaurant_data.is_open

        self.db.commit()
        self.db.refresh(restaurant)

        return restaurant

    def patch(self, restaurant, updates):
        # La PATCH nu stim dinainte ce campuri au fost trimise.
        #
        # updates este un dictionar.
        for key in updates:
            setattr(
                restaurant,
                key,
                updates[key]
            )

        self.db.commit()
        self.db.refresh(restaurant)

        return restaurant

    def delete(self, restaurant):
        self.db.delete(restaurant)
        self.db.commit()