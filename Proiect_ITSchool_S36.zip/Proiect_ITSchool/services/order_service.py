class OrderService:
    def __init__(self, orders):
        self.orders = orders

        self.valid_statuses = [
            "new",
            "confirmed",
            "preparing",
            "out_for_delivery",
            "delivered",
            "cancelled"
        ]

    def get_all(
        self,
        order_status=None,
        min_price=None,
        max_price=None,
        customer_name=None
    ):
        filtered_orders = []

        for order in self.orders:
            if order_status is not None:
                if order["status"].lower() != order_status.lower():
                    continue

            if min_price is not None:
                if order["total_price"] < min_price:
                    continue

            if max_price is not None:
                if order["total_price"] > max_price:
                    continue

            if customer_name is not None:
                if (
                    customer_name.lower()
                    not in order["customer_name"].lower()
                ):
                    continue

            filtered_orders.append(order)

        return filtered_orders

    def find_by_id(self, order_id):
        for order in self.orders:
            if order["id"] == order_id:
                return order

        return None

    def get_next_id(self):
        max_id = 0

        for order in self.orders:
            if order["id"] > max_id:
                max_id = order["id"]

        return max_id + 1

    def status_is_valid(self, order_status):
        return order_status.lower() in self.valid_statuses

    def create(self, order_data):
        new_order = {
            "id": self.get_next_id(),
            "customer_name": order_data.customer_name,
            "total_price": order_data.total_price,
            "number_of_products": order_data.number_of_products,
            "delivery_fee": order_data.delivery_fee,
            "status": order_data.status.lower()
        }

        self.orders.append(new_order)

        return new_order

    def update(self, order, order_data):
        order["customer_name"] = order_data.customer_name
        order["total_price"] = order_data.total_price
        order["number_of_products"] = order_data.number_of_products
        order["delivery_fee"] = order_data.delivery_fee
        order["status"] = order_data.status.lower()

        return order

    def patch(self, order, updates):
        for key in updates:
            order[key] = updates[key]

        return order

    def delete(self, order):
        self.orders.remove(order)

        return order