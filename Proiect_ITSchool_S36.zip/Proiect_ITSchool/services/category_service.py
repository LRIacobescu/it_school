from sqlalchemy import func # functii SQL
from sqlalchemy import select # construize comenzi SQL

from models import Category # Model ORM care reprezinta tabele
from models import Product # Model ORM care reprezinta tabele

class CategoryService:
    def __init__(self, db):
        self.db = db

    def get_all(self):
        query = select(Category).order_by(Category.id)

        categories = self.db.scalars(query).all()

        return categories

    def find_by_id(self, category_id):
        category = self.db.get(Category, category_id)

        return category

    def name_exists(self, category_name, excluded_id = None):
        query = select(Category).where(func.lower(Category.name) == category_name.lower())

        if excluded_id is not None:
            query = query.where(Category.id != excluded_id)

        category = self.db.scalar(query)

        if category is None:
            return False

        return True

    def create(self, category_data):
        new_category = Category(
            name = category_data.name.lower()
        )

        self.db.add(new_category)
        self.db.commit()
        self.db.refresh(new_category)

        return new_category

    def delete(self, category):
        self.db.delete(category)
        self.db.commit()

    def is_used(self, category_name):
        query = select(Product).where(Product.category == category_name.lower()) # ex: WHERE LOWER(name) = 'pizza'

        product = self.db.scalar(query)

        if product is None:
            return False

        return True

    def update(self, category, category_data):

        old_name = category.name
        new_name = category_data.name.lower()
        category.name = new_name

        query = select(Product).where(Product.category == old_name)

        products = self.db.scalars(query).all()

        for product in products:
            product.category = new_name

        self.db.commit()
        self.db.refresh(category)

        return category

    def patch(self, category, updates):

        old_name = category.name
        new_name = updates["name"].lower()
        category.name = new_name

        query = select(Product).where(Product.category == old_name)

        products = self.db.scalars(query).all()

        for product in products:
            product.category = new_name

        self.db.commit()
        self.db.refresh(category)

        return category

# scalars -> folosit cand vrem mai multe rezultate. Returneaza un obiect care poate oferi toate obiectele selectate
#            -> prin .all() obtinem lista completa: [Category(....), Category(....), ....]

# scalar -> folosim cand ne intereseaza doar primul rezultat sau None: Category(...) / None

# func.lower(Category.name) -> SQL: LOWER(name)