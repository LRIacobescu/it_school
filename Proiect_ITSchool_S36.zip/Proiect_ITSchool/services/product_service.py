from sqlalchemy import func
from sqlalchemy import select

from models import Category
from models import Product

class ProductService:
    def __init__(self, db):
        self.db = db

    def get_all(self, category = None, available = None, min_price = None, max_price = None, name = None):
        query = select(Product) # SELECT * FROM products;

        if category is not None:
            query = query.where(Product.category == category.lower()) # WHERE category = true;

        if available is not None:
            query = query.where(Product.available == available)

        if min_price is not None:
            query = query.where(Product.price >= min_price) # WHERE price >= 30;

        if max_price is not None:
            query = query.where(Product.price <= max_price)

        if name is not None:
            query = query.where(Product.name.ilike("%" + name + "%"))

        query = query.order_by(Product.id)

        products = self.db.scalars(query).all() # Executam statementul si rezultattul contine obiecte Product

        return products

    def find_by_id(self, product_id):
        product = self.db.get(Product, product_id) # Cautare dupa id
        return product

    def category_exists(self, category_name):
        query = select(Category).where(func.lower(Category.name) == category_name.lower())

        category = self.db.scalar(query)

        if category is None:
            return False

        return True

    def name_exists(self, product_name, excluded_id=None):
        query = select(Product).where(func.lower(Product.name) == product_name.lower())

        if excluded_id is not None:
            query = query.where(Product.id != excluded_id)

        product = self.db.scalar(query)

        if product is None:
            return False

        return True

    def create(self, product_data):
        new_product = Product(
            name = product_data.name,
            description = product_data.description,
            price = product_data.price,
            category = product_data.category.lower(),
            available = product_data.available,
        )

        self.db.add(new_product) # INSERT
        self.db.commit() # salvam tranzactia
        self.db.refresh(new_product) # reincarcam datele generate; dupa refresh, obiectul contine si id generat

        return new_product

    def update(self, product, product_data):
        product.name = product_data.name
        product.description = product_data.description
        product.price = product_data.price
        product.category = product_data.category.lower()
        product.available = product_data.available

        self.db.commit() # detecteaza modificarile facute mai sus si executa UPDATE
        self.db.refresh(product)

        return product

    def patch(self, product, updates):
        for key in updates:
            value = updates[key]

            if key == "category":
                value = value.lower()

            setattr(product, key, value) # echivalent cu category.name = "Pizza" / product.price = 50

        self.db.commit()
        self.db.refresh(product)
        return product

    def delete(self, product):
        self.db.delete(product) # DELETE FROM products WHERE id = ...;
        self.db.commit()