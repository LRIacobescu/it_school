from sqlalchemy import select

from models import Courier


class CourierService:
    def __init__(self, db):
        # Salvam sesiunea SQLAlchemy.
        self.db = db

    def get_all(
        self,
        active=None,
        first_name=None,
        last_name=None
    ):
        # SELECT * FROM couriers
        statement = select(Courier)

        if active is not None:
            statement = statement.where(
                Courier.active == active
            )

        # ilike permite cautarea dupa o parte din text,
        # fara diferenta intre litere mari si mici.
        if first_name is not None:
            statement = statement.where(
                Courier.first_name.ilike(
                    "%" + first_name + "%"
                )
            )

        if last_name is not None:
            statement = statement.where(
                Courier.last_name.ilike(
                    "%" + last_name + "%"
                )
            )

        statement = statement.order_by(
            Courier.id
        )

        couriers = self.db.scalars(
            statement
        ).all()

        return couriers

    def find_by_id(self, courier_id):
        courier = self.db.get(
            Courier,
            courier_id
        )

        return courier

    def phone_exists(
        self,
        phone,
        excluded_id=None
    ):
        statement = select(Courier).where(
            Courier.phone == phone
        )

        # La PUT si PATCH nu verificam curierul actual
        # impotriva propriului numar de telefon.
        if excluded_id is not None:
            statement = statement.where(
                Courier.id != excluded_id
            )

        courier = self.db.scalar(statement)

        return courier is not None

    def create(self, courier_data):
        new_courier = Courier(
            first_name=courier_data.first_name,
            last_name=courier_data.last_name,
            phone=courier_data.phone,
            active=courier_data.active
        )

        self.db.add(new_courier)
        self.db.commit()
        self.db.refresh(new_courier)

        return new_courier

    def update(self, courier, courier_data):
        courier.first_name = courier_data.first_name
        courier.last_name = courier_data.last_name
        courier.phone = courier_data.phone
        courier.active = courier_data.active

        self.db.commit()
        self.db.refresh(courier)

        return courier

    def patch(self, courier, updates):
        for key in updates:
            setattr(
                courier,
                key,
                updates[key]
            )

        self.db.commit()
        self.db.refresh(courier)

        return courier

    def delete(self, courier):
        self.db.delete(courier)
        self.db.commit()