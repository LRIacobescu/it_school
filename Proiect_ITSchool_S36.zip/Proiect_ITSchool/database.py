from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import sessionmaker

DATABASE_URL = ("postgresql+psycopg://postgres:"
                "admin@localhost:5433/it_school_db")

engine = create_engine(DATABASE_URL, echo=True) # obiectul principal prin care SQL gestioneaza conexiunile catre db

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base() # toate clasele care reprezinta tabele mostenesc Base

def get_db():
    db = SessionLocal() # Se creeaza sesiunea

    try:
        yield db
    finally:
        db.close()