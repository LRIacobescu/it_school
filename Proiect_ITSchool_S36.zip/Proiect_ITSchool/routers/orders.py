from typing import Optional

from fastapi import APIRouter
from fastapi import HTTPException
from fastapi import status

from data import orders
from schemas import OrderCreate
from schemas import OrderPatch
from schemas import OrderUpdate
from services.order_service import OrderService


router = APIRouter(
    prefix="/orders",
    tags=["Orders"]
)


order_service = OrderService(orders)


@router.get("")
def get_orders(
    order_status: Optional[str] = None,
    min_price: Optional[float] = None,
    max_price: Optional[float] = None,
    customer_name: Optional[str] = None
):
    if min_price is not None and max_price is not None:
        if min_price > max_price:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=(
                    "Pretul minim nu poate fi "
                    "mai mare decat pretul maxim"
                )
            )

    if order_status is not None:
        if order_service.status_is_valid(order_status) is False:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Statusul comenzii nu este valid"
            )

    return order_service.get_all(
        order_status,
        min_price,
        max_price,
        customer_name
    )


@router.get("/{order_id}")
def get_order_by_id(order_id: int):
    order = order_service.find_by_id(order_id)

    if order is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Comanda nu a fost gasita"
        )

    return order


@router.post(
    "",
    status_code=status.HTTP_201_CREATED
)
def create_order(order: OrderCreate):
    if order_service.status_is_valid(order.status) is False:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Statusul comenzii nu este valid"
        )

    return order_service.create(order)


@router.put("/{order_id}")
def update_order(
    order_id: int,
    updated_order: OrderUpdate
):
    order = order_service.find_by_id(order_id)

    if order is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Comanda nu a fost gasita"
        )

    if order_service.status_is_valid(
        updated_order.status
    ) is False:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Statusul comenzii nu este valid"
        )

    return order_service.update(
        order,
        updated_order
    )


@router.patch("/{order_id}")
def patch_order(
    order_id: int,
    order_update: OrderPatch
):
    order = order_service.find_by_id(order_id)

    if order is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Comanda nu a fost gasita"
        )

    updates = order_update.model_dump(
        exclude_unset=True
    )

    if len(updates) == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Trebuie trimis cel putin un camp"
        )

    if "status" in updates:
        if order_service.status_is_valid(
            updates["status"]
        ) is False:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Statusul comenzii nu este valid"
            )

        updates["status"] = updates["status"].lower()

    return order_service.patch(
        order,
        updates
    )


@router.delete("/{order_id}")
def delete_order(order_id: int):
    order = order_service.find_by_id(order_id)

    if order is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Comanda nu a fost gasita"
        )

    if order["status"] == "delivered":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "O comanda livrata "
                "nu poate fi stearsa"
            )
        )

    deleted_order = order_service.delete(order)

    return {
        "message": "Comanda a fost stearsa",
        "deleted_order": deleted_order
    }