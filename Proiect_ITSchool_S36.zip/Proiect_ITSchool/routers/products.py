from typing import Optional

from fastapi import APIRouter
from fastapi import HTTPException
from fastapi import status
from fastapi import Depends
from sqlalchemy.orm import Session

from database import get_db
from schemas import ProductCreate
from schemas import ProductPatch
from schemas import ProductUpdate
from schemas import ProductResponse
from services.product_service import ProductService


router = APIRouter(
    prefix="/products",
    tags=["Products"]
)

@router.get("")
def get_products(
    category: Optional[str] = None,
    available: Optional[bool] = None,
    min_price: Optional[float] = None,
    max_price: Optional[float] = None,
    name: Optional[str] = None,
    db: Session = Depends(get_db) # db: Session ->Variabila db va contine un obiect de tip Session(intelegerea metodelor disponibile[db.add, db.commit, db.refresh, db.delete...])
                                    # Depends(get_db) -> spune cum va fi obtinuta valoarea(tipul valorii -> Session / modul de obtinere -> get_db)
):
    if min_price is not None and max_price is not None:
        if min_price > max_price:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=(
                    "Pretul minim nu poate fi "
                    "mai mare decat pretul maxim"
                )
            )

    product_service = ProductService(db)

    products = product_service.get_all(
        category,
        available,
        min_price,
        max_price,
        name
    )

    return products


@router.get("/{product_id}", response_model = ProductResponse)
def get_product_by_id(product_id: int, db: Session = Depends(get_db)):
    product_service = ProductService(db)

    product = product_service.find_by_id(product_id)

    if product is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Produsul nu a fost gasit"
        )

    return product


@router.post(
    "",
    status_code=status.HTTP_201_CREATED,
    response_model = ProductResponse
)
def create_product(product: ProductCreate, db: Session = Depends(get_db)):
    product_service = ProductService(db)

    if product_service.category_exists(product.category) is False:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Categoria nu exista"
        )

    if product_service.name_exists(product.name):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Exista deja un produs cu acest nume"
        )

    new_product = product_service.create(product)

    return new_product


@router.put("/{product_id}", response_model = ProductResponse)
def update_product(
    product_id: int, # Path parameter
    updated_product: ProductUpdate, # Request body
    db: Session = Depends(get_db) # dependinta, creata de fastapi
):
    product_service = ProductService(db)
    product = product_service.find_by_id(product_id)

    if product is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Produsul nu a fost gasit"
        )

    if product_service.category_exists(
        updated_product.category
    ) is False:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Categoria nu exista"
        )

    if product_service.name_exists(
        updated_product.name,
        product_id
    ):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Exista deja un produs cu acest nume"
        )

    product = product_service.update(
        product,
        updated_product
    )
    return product


@router.patch("/{product_id}", response_model = ProductResponse)
def patch_product(
    product_id: int,
    product_update: ProductPatch,
    db: Session = Depends(get_db)
):
    product_service = ProductService(db)

    product = product_service.find_by_id(product_id)

    if product is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Produsul nu a fost gasit"
        )

    updates = product_update.model_dump(
        exclude_unset=True
    )

    if len(updates) == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Trebuie trimis cel putin un camp"
        )

    if "category" in updates:
        if product_service.category_exists(
            updates["category"]
        ) is False:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Categoria nu exista"
            )

        # updates["category"] = updates["category"].lower()

    if "name" in updates:
        if product_service.name_exists(
            updates["name"],
            product_id
        ):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Exista deja un produs cu acest nume"
            )

    product = product_service.patch(
        product,
        updates
    )
    return product


@router.delete("/{product_id}")
def delete_product(product_id: int, db: Session = Depends(get_db)):
    product_service = ProductService(db)

    product = product_service.find_by_id(product_id)

    if product is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Produsul nu a fost gasit"
        )

    product_service.delete(product)

    return {
        "message": "Produsul a fost sters"
    }