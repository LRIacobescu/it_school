from typing import Optional

from fastapi import APIRouter
from fastapi import Depends
from fastapi import HTTPException
from fastapi import status
from sqlalchemy.orm import Session

from database import get_db
from schemas import CourierCreate
from schemas import CourierPatch
from schemas import CourierResponse
from schemas import CourierUpdate
from services.courier_service import CourierService


router = APIRouter(
    prefix="/couriers",
    tags=["Couriers"]
)


@router.get(
    "",
    response_model=list[CourierResponse]
)
def get_couriers(
    active: Optional[bool] = None,
    first_name: Optional[str] = None,
    last_name: Optional[str] = None,
    db: Session = Depends(get_db)
):
    courier_service = CourierService(db)

    couriers = courier_service.get_all(
        active,
        first_name,
        last_name
    )

    return couriers


@router.get(
    "/{courier_id}",
    response_model=CourierResponse
)
def get_courier_by_id(
    courier_id: int,
    db: Session = Depends(get_db)
):
    courier_service = CourierService(db)

    courier = courier_service.find_by_id(
        courier_id
    )

    if courier is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Curierul nu a fost gasit"
        )

    return courier


@router.post(
    "",
    status_code=status.HTTP_201_CREATED,
    response_model=CourierResponse
)
def create_courier(
    courier: CourierCreate,
    db: Session = Depends(get_db)
):
    courier_service = CourierService(db)

    # Nu permitem doi curieri
    # cu acelasi numar de telefon.
    if courier_service.phone_exists(
        courier.phone
    ):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "Exista deja un curier "
                "cu acest numar de telefon"
            )
        )

    new_courier = courier_service.create(
        courier
    )

    return new_courier


@router.put(
    "/{courier_id}",
    response_model=CourierResponse
)
def update_courier(
    courier_id: int,
    updated_courier: CourierUpdate,
    db: Session = Depends(get_db)
):
    courier_service = CourierService(db)

    courier = courier_service.find_by_id(
        courier_id
    )

    if courier is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Curierul nu a fost gasit"
        )

    if courier_service.phone_exists(
        updated_courier.phone,
        courier_id
    ):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "Exista deja un curier "
                "cu acest numar de telefon"
            )
        )

    courier = courier_service.update(
        courier,
        updated_courier
    )

    return courier


@router.patch(
    "/{courier_id}",
    response_model=CourierResponse
)
def patch_courier(
    courier_id: int,
    courier_update: CourierPatch,
    db: Session = Depends(get_db)
):
    courier_service = CourierService(db)

    courier = courier_service.find_by_id(
        courier_id
    )

    if courier is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Curierul nu a fost gasit"
        )

    updates = courier_update.model_dump(
        exclude_unset=True
    )

    if len(updates) == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Trebuie trimis cel putin un camp"
        )

    # Verificam numarul doar daca a fost trimis.
    if "phone" in updates:
        if courier_service.phone_exists(
            updates["phone"],
            courier_id
        ):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                    "Exista deja un curier "
                    "cu acest numar de telefon"
                )
            )

    courier = courier_service.patch(
        courier,
        updates
    )

    return courier


@router.delete("/{courier_id}")
def delete_courier(
    courier_id: int,
    db: Session = Depends(get_db)
):
    courier_service = CourierService(db)

    courier = courier_service.find_by_id(
        courier_id
    )

    if courier is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Curierul nu a fost gasit"
        )

    # Pastram regula din proiect:
    # un curier activ nu poate fi sters.
    if courier.active is True:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Un curier activ nu poate fi sters"
        )

    courier_service.delete(courier)

    return {
        "message": "Curierul a fost sters"
    }