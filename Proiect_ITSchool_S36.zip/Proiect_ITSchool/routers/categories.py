from fastapi import APIRouter
from fastapi import HTTPException
from fastapi import status
from fastapi import Depends
from sqlalchemy.orm import Session

from database import get_db
from schemas import CategoryCreate
from schemas import CategoryPatch
from schemas import CategoryUpdate
from schemas import CategoryResponse
from services.category_service import CategoryService


router = APIRouter(
    prefix="/categories",
    tags=["Categories"]
)


@router.get("", response_model = list[CategoryResponse])
def get_categories(db: Session = Depends(get_db)):
    category_service= CategoryService(db)
    categories = category_service.get_all()

    return categories


@router.get("/{category_id}", response_model = CategoryResponse)
def get_category_by_id(category_id: int, db: Session = Depends(get_db)):
    category_service = CategoryService(db)

    category = category_service.find_by_id(category_id)

    if category is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Categoria nu a fost gasita"
        )

    return category


@router.post(
    "",
    status_code=status.HTTP_201_CREATED,
    response_model = CategoryResponse
)
def create_category(category: CategoryCreate, db: Session = Depends(get_db)):
    category_service = CategoryService(db)

    if category_service.name_exists(category.name):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Categoria exista deja"
        )

    return category_service.create(category)


@router.put("/{category_id}", response_model = CategoryResponse)
def update_category(
    category_id: int,
    updated_category: CategoryUpdate,
    db: Session = Depends(get_db)
):
    category_service = CategoryService(db)
    category = category_service.find_by_id(category_id)

    if category is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Categoria nu a fost gasita"
        )

    if category_service.name_exists(
        updated_category.name,
        category_id
    ):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Categoria exista deja"
        )

    return category_service.update(
        category,
        updated_category
    )


@router.patch("/{category_id}", response_model = CategoryResponse)
def patch_category(
    category_id: int,
    category_update: CategoryPatch,
    db: Session = Depends(get_db)
):
    category_service = CategoryService(db)
    category = category_service.find_by_id(category_id)

    if category is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Categoria nu a fost gasita"
        )

    updates = category_update.model_dump(
        exclude_unset=True
    )

    if len(updates) == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Trebuie trimis cel putin un camp"
        )

    if category_service.name_exists(
        updates["name"],
        category_id
    ):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Categoria exista deja"
        )

    return category_service.patch(
        category,
        updates
    )


@router.delete("/{category_id}")
def delete_category(
    category_id: int,
    db: Session = Depends(get_db)
):
    category_service = CategoryService(db)
    category = category_service.find_by_id(category_id)

    if category is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Categoria nu a fost gasita"
        )

    if category_service.is_used(category.name):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "Categoria nu poate fi stearsa "
                "deoarece este folosita de produse"
            )
        )

    category_service.delete(category)

    return {
        "message": "Categoria a fost stearsa"
    }