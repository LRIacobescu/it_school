from typing import Optional

from fastapi import APIRouter
from fastapi import Depends
from fastapi import HTTPException
from fastapi import status
from sqlalchemy.orm import Session

from database import get_db
from schemas import RestaurantCreate
from schemas import RestaurantPatch
from schemas import RestaurantResponse
from schemas import RestaurantUpdate
from services.restaurant_service import RestaurantService


router = APIRouter(
    prefix="/restaurants",
    tags=["Restaurants"]
)


@router.get(
    "",
    response_model=list[RestaurantResponse]
)
def get_restaurants(
    city: Optional[str] = None,
    is_open: Optional[bool] = None,
    min_rating: Optional[float] = None,
    name: Optional[str] = None,

    # FastAPI apeleaza get_db si ofera endpoint-ului
    # o sesiune SQLAlchemy.
    db: Session = Depends(get_db)
):
    restaurant_service = RestaurantService(db)

    restaurants = restaurant_service.get_all(
        city,
        is_open,
        min_rating,
        name
    )

    return restaurants


@router.get(
    "/{restaurant_id}",
    response_model=RestaurantResponse
)
def get_restaurant_by_id(
    restaurant_id: int,
    db: Session = Depends(get_db)
):
    restaurant_service = RestaurantService(db)

    restaurant = restaurant_service.find_by_id(
        restaurant_id
    )

    if restaurant is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Restaurantul nu a fost gasit"
        )

    return restaurant


@router.post(
    "",
    status_code=status.HTTP_201_CREATED,
    response_model=RestaurantResponse
)
def create_restaurant(
    restaurant: RestaurantCreate,
    db: Session = Depends(get_db)
):
    restaurant_service = RestaurantService(db)

    # Verificam daca exista acelasi restaurant
    # in acelasi oras.
    if restaurant_service.restaurant_exists(
        restaurant.name,
        restaurant.city
    ):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "Restaurantul exista deja "
                "in acest oras"
            )
        )

    new_restaurant = restaurant_service.create(
        restaurant
    )

    return new_restaurant


@router.put(
    "/{restaurant_id}",
    response_model=RestaurantResponse
)
def update_restaurant(
    restaurant_id: int,
    updated_restaurant: RestaurantUpdate,
    db: Session = Depends(get_db)
):
    restaurant_service = RestaurantService(db)

    restaurant = restaurant_service.find_by_id(
        restaurant_id
    )

    if restaurant is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Restaurantul nu a fost gasit"
        )

    # Verificam duplicatul si excludem
    # restaurantul actual.
    if restaurant_service.restaurant_exists(
        updated_restaurant.name,
        updated_restaurant.city,
        restaurant_id
    ):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "Restaurantul exista deja "
                "in acest oras"
            )
        )

    restaurant = restaurant_service.update(
        restaurant,
        updated_restaurant
    )

    return restaurant


@router.patch(
    "/{restaurant_id}",
    response_model=RestaurantResponse
)
def patch_restaurant(
    restaurant_id: int,
    restaurant_update: RestaurantPatch,
    db: Session = Depends(get_db)
):
    restaurant_service = RestaurantService(db)

    restaurant = restaurant_service.find_by_id(
        restaurant_id
    )

    if restaurant is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Restaurantul nu a fost gasit"
        )

    # Pastram doar campurile trimise efectiv.
    updates = restaurant_update.model_dump(
        exclude_unset=True
    )

    if len(updates) == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Trebuie trimis cel putin un camp"
        )

    # Pornim de la valorile existente.
    final_name = restaurant.name
    final_city = restaurant.city

    # Daca clientul trimite un nume nou,
    # acesta devine numele final.
    if "name" in updates:
        final_name = updates["name"]

    # Daca trimite un oras nou,
    # acesta devine orasul final.
    if "city" in updates:
        final_city = updates["city"]

    # Verificam combinatia care va ramane dupa PATCH.
    if restaurant_service.restaurant_exists(
        final_name,
        final_city,
        restaurant_id
    ):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "Restaurantul exista deja "
                "in acest oras"
            )
        )

    restaurant = restaurant_service.patch(
        restaurant,
        updates
    )

    return restaurant


@router.delete("/{restaurant_id}")
def delete_restaurant(
    restaurant_id: int,
    db: Session = Depends(get_db)
):
    restaurant_service = RestaurantService(db)

    restaurant = restaurant_service.find_by_id(
        restaurant_id
    )

    if restaurant is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Restaurantul nu a fost gasit"
        )

    restaurant_service.delete(restaurant)

    return {
        "message": "Restaurantul a fost sters"
    }