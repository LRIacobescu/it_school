from typing import Optional

from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import Field


# =========================================================
# SCHEME PENTRU CATEGORII
# =========================================================


class CategoryCreate(BaseModel):
    name: str = Field(
        min_length=2,
        max_length=100
    )


class CategoryUpdate(BaseModel):
    name: str = Field(
        min_length=2,
        max_length=100
    )


class CategoryPatch(BaseModel):
    name: Optional[str] = Field(
        default=None,
        min_length=2,
        max_length=100
    )


class CategoryResponse(BaseModel):
    # Permite citirea valorilor din atributele
    # obiectelor ORM SQLAlchemy.
    model_config = ConfigDict(
        from_attributes=True
    )

    id: int
    name: str


# =========================================================
# SCHEME PENTRU PRODUSE
# =========================================================


class ProductCreate(BaseModel):
    name: str = Field(
        min_length=2,
        max_length=100
    )

    description: str = Field(
        default="",
        max_length=500
    )

    price: float = Field(gt=0)

    # Categoria este inca primita ca text.
    # In sesiunea 7 va deveni category_id.
    category: str = Field(
        min_length=2,
        max_length=100
    )

    available: bool = True


class ProductUpdate(BaseModel):
    name: str = Field(
        min_length=2,
        max_length=100
    )

    description: str = Field(
        max_length=500
    )

    price: float = Field(gt=0)

    category: str = Field(
        min_length=2,
        max_length=100
    )

    available: bool


class ProductPatch(BaseModel):
    name: Optional[str] = Field(
        default=None,
        min_length=2,
        max_length=100
    )

    description: Optional[str] = Field(
        default=None,
        max_length=500
    )

    price: Optional[float] = Field(
        default=None,
        gt=0
    )

    category: Optional[str] = Field(
        default=None,
        min_length=2,
        max_length=100
    )

    available: Optional[bool] = None


class ProductResponse(BaseModel):
    model_config = ConfigDict(
        from_attributes=True
    )

    id: int
    name: str
    description: str
    price: float
    category: str
    available: bool


# =========================================================
# SCHEME PENTRU RESTAURANTE
# =========================================================


class RestaurantCreate(BaseModel):
    name: str = Field(
        min_length=2,
        max_length=100
    )

    city: str = Field(
        min_length=2,
        max_length=100
    )

    address: str = Field(
        min_length=5,
        max_length=200
    )

    rating: float = Field(
        ge=0,
        le=5
    )

    is_open: bool = True


class RestaurantUpdate(BaseModel):
    name: str = Field(
        min_length=2,
        max_length=100
    )

    city: str = Field(
        min_length=2,
        max_length=100
    )

    address: str = Field(
        min_length=5,
        max_length=200
    )

    rating: float = Field(
        ge=0,
        le=5
    )

    is_open: bool


class RestaurantPatch(BaseModel):
    name: Optional[str] = Field(
        default=None,
        min_length=2,
        max_length=100
    )

    city: Optional[str] = Field(
        default=None,
        min_length=2,
        max_length=100
    )

    address: Optional[str] = Field(
        default=None,
        min_length=5,
        max_length=200
    )

    rating: Optional[float] = Field(
        default=None,
        ge=0,
        le=5
    )

    is_open: Optional[bool] = None


class RestaurantResponse(BaseModel):
    model_config = ConfigDict(
        from_attributes=True
    )

    id: int
    name: str
    city: str
    address: str
    rating: float
    is_open: bool


# =========================================================
# SCHEME PENTRU CURIERI
# =========================================================


class CourierCreate(BaseModel):
    first_name: str = Field(
        min_length=2,
        max_length=100
    )

    last_name: str = Field(
        min_length=2,
        max_length=100
    )

    phone: str = Field(
        min_length=10,
        max_length=20
    )

    active: bool = True


class CourierUpdate(BaseModel):
    first_name: str = Field(
        min_length=2,
        max_length=100
    )

    last_name: str = Field(
        min_length=2,
        max_length=100
    )

    phone: str = Field(
        min_length=10,
        max_length=20
    )

    active: bool


class CourierPatch(BaseModel):
    first_name: Optional[str] = Field(
        default=None,
        min_length=2,
        max_length=100
    )

    last_name: Optional[str] = Field(
        default=None,
        min_length=2,
        max_length=100
    )

    phone: Optional[str] = Field(
        default=None,
        min_length=10,
        max_length=20
    )

    active: Optional[bool] = None


class CourierResponse(BaseModel):
    model_config = ConfigDict(
        from_attributes=True
    )

    id: int
    first_name: str
    last_name: str
    phone: str
    active: bool