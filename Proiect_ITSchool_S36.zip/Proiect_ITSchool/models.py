from sqlalchemy import Boolean
from sqlalchemy import Column
from sqlalchemy import Float
from sqlalchemy import Integer
from sqlalchemy import String

from database import Base

class Category(Base):
    __tablename__ = "categories"

    # Cheia primara
    id = Column(
        Integer,
        primary_key = True,
        index = True
    )

    # Nume categorie: trebuie sa fie unic si obligatoriu
    name = Column(
        String(100),
        unique = True,
        nullable = False
    )

class Product(Base):
    __tablename__ = "products"

    id = Column(
        Integer,
        primary_key = True,
        index = True
    )

    name = Column(
        String(100),
        unique = True,
        nullable = False
    )

    description = Column(
        String(500),
        default = ""
    )

    price = Column(
        Float,
        nullable = False
    )

    category = Column(
        String(100),
        nullable = False
    )

    available = Column(
        Boolean,
        default = True,
        nullable = False
    )

class Restaurant(Base):
    __tablename__ = "restaurants"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    city = Column(String(100), nullable=False)
    address = Column(String(200), nullable=False)
    rating = Column(Float, nullable=False)
    is_open = Column(Boolean, default=True, nullable=False)

class Courier(Base):
    __tablename__ = "couriers"

    id = Column(Integer, primary_key=True, index=True)
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    phone = Column(String(20), unique=True, nullable=False)
    active = Column(Boolean, default=True, nullable=False)

